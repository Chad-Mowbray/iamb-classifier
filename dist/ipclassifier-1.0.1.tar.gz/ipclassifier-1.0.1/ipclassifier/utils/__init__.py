from .dicts import DictsSingleton
