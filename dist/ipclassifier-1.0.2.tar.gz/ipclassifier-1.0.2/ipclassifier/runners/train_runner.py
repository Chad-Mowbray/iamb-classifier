from ipclassifier.classifier import ModelTrainer
from .feature_runner import FeatureRunner 



def train_runner():
    ModelTrainer(FeatureRunner)


